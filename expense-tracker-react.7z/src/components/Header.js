import React from 'react'

export const Header = () => {
  return (
    <h2>
      Expense tracker
    </h2>
  )
}

export default Header
